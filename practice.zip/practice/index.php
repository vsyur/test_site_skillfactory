

<?php 
 $p = 'Приветствую Вас на моей страничке!';
?>

<?php 
 $name = 'Сергей';
 $surname = 'Вартаньян';
 $city = 'Москва';
 $age = 23;
?>


<?php
include 'main.php';
?>

